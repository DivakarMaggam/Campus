const form = document.getElementById("itemForm");

form.addEventListener("submit", async (e) => {

    e.preventDefault();

    const formData = new FormData();

    formData.append("itemName", document.getElementById("itemName").value);
    formData.append("category", document.getElementById("category").value);
    formData.append("description", document.getElementById("description").value);
    formData.append("location", document.getElementById("location").value);
    formData.append("date", document.getElementById("date").value);
    formData.append("status", document.getElementById("status").value);
    formData.append("reportedBy", localStorage.getItem("userEmail"));

    const image = document.getElementById("image").files[0];

    if (image) {
        formData.append("image", image);
    }

    const response = await fetch("http://localhost:8080/api/items/report", {

        method: "POST",

        body: formData

    });

    const message = await response.text();

    document.getElementById("message").innerHTML =
        `<div class="alert alert-success">${message}</div>`;

    form.reset();

});