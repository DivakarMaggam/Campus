let allItems = [];

async function loadItems() {

    const response = await fetch("http://localhost:8080/api/items");

    allItems = await response.json();

    displayItems(allItems);
}

function displayItems(items) {

    const table = document.getElementById("itemTable");

    table.innerHTML = "";

    items.forEach(item => {

        table.innerHTML += `

        <tr>

            <td>${item.id}</td>

            <td>
                ${
                    item.image
                    ? `<img src="http://localhost:8080/uploads/${item.image}"
                           width="100"
                           height="100"
                           style="object-fit:cover;border-radius:8px;">`
                    : "No Image"
                }
            </td>

            <td>${item.itemName}</td>

            <td>${item.category}</td>

            <td>${item.location}</td>

            <td>${item.status}</td>

            <td>

                <a href="claim.html?id=${item.id}"
                   class="btn btn-success btn-sm">

                   Claim

                </a>

            </td>

        </tr>

        `;

    });

}

function searchItems() {

    const keyword = document
        .getElementById("search")
        .value
        .toLowerCase();

    const filtered = allItems.filter(item =>
        item.itemName.toLowerCase().includes(keyword)
    );

    displayItems(filtered);
}

loadItems();