const params = new URLSearchParams(window.location.search);

document.getElementById("itemId").value = params.get("id");
document.getElementById("email").value = localStorage.getItem("userEmail");

const form = document.getElementById("claimForm");

form.addEventListener("submit", async (e) => {

    e.preventDefault();

    const claim = {

        itemId: Number(document.getElementById("itemId").value),

        userEmail: document.getElementById("email").value,

        claimReason: document.getElementById("proof").value

    };

    const response = await fetch("http://localhost:8080/api/claims/submit", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify(claim)

    });

    const message = await response.text();

    document.getElementById("message").innerHTML =
        `<div class="alert alert-success">${message}</div>`;

    form.reset();

    document.getElementById("itemId").value = params.get("id");
    document.getElementById("email").value = localStorage.getItem("userEmail");

});